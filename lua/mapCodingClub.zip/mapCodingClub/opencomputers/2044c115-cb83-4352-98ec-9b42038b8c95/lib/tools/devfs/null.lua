return
{
  open = function(mode)
    return
    {
      read = function() end,
      write = function() end
    }
  end
}
